<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\lote;
use Faker\Generator as Faker;

$factory->define(lote::class, function (Faker $faker) {
    return [
        //
    ];
});
